# φ

Security toolkit for your computer.

## Install

**Linux**
```
curl -sL https://raw.githubusercontent.com/prism-iq/ieud/main/install.sh | sudo bash
```

**Mac**
```
curl -sL https://raw.githubusercontent.com/prism-iq/ieud/main/install-mac.sh | bash
```

**Windows** (PowerShell Admin)
```
iwr -useb https://raw.githubusercontent.com/prism-iq/ieud/main/install.ps1 | iex
```

## Use

Type `ζ` to run. That's it.

```
ζ        all
ζ s      kill threats
ζ v      check files
ζ k      watch network
ζ a      clean junk
```

Can't type Greek? Use `ω` with any word:
```
ω clean
ω check
ω kill
```

## Stop

Hold Right Ctrl for 3 seconds.

## License

MIT
